queueExtensionToLoad('RaceMP')
queueExtensionToLoad('GUI')
